/*main.cpp*/

//
// myDB project using AVL trees
//
// Joseph Lenaghan
// U. of Illinois, Chicago
// CS 251: Fall 2019
// Project #04
//

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <cassert>

#include "avl.h"
#include "util.h"

using namespace std;


//
// tokenize
//
// Given a string, breaks the string into individual tokens (words) based
// on spaces between the tokens.  Returns the tokens back in a vector.
//
// Example: "select * from students" would be tokenized into a vector
// containing 4 strings:  "select", "*", "from", "students".
//
vector<string> tokenize(string line)
{
  vector<string> tokens;
  stringstream  stream(line);
  string token;

  while (getline(stream, token, ' '))
  {
    tokens.push_back(token);
  }

  return tokens;
}
/* grabs data from the meta file and properly allocates each column to its respectively mapped spot in the tree */
void inputMetaData(string tablename,int& recordSize, int& numColumn,vector<string> &strings,vector<int> &nums)
{
	string   filename = tablename + ".meta"; //add meta to the string to make it a file...
	ifstream openFile(filename); // open  the file...
	int num; // this will hold integer read-ins from the file...
	string value; // this will string read-ins from the file...
	
	if(!openFile.good()) // check to see if the file opened correctly
	{
		cout << "Error: unable to open meta file...";
		cout << "Exiting...";
		return; // exit ...
	}
	
	openFile >> recordSize; // read in the offset...
	while(!openFile.eof()) // while we havent hit the end of the file..
	{
	openFile >> numColumn; // read in the number of columns per data line...
	for(int i = 0; i < numColumn; i++)
	{
	openFile >> value; // read in a string...
	strings.push_back(value); // push the string into the vector...
	openFile >> num; // read in an int...
	nums.push_back(num); // push the integer into the vector...
	}
	openFile >> recordSize;
	}

	
}
/* grabs data from the data file and properly allocates each of column of data that IS indexed into a tree
 * for example, UIN and netid are indexed columns in students.data so we would use this function to build trees for them */
avltree<string,streamoff> BuildIndexTree(string tablename, int recordSize,int numColumn,int colIndex)
{
  avltree<string,streamoff>  newTree; // declare a tree to will return to main when done...
  vector<string> values; // vector to hold the entire line of input...
  string   filename = tablename + ".data"; // create a file by adding .data to the string...
  ifstream data(filename, ios::in | ios::binary); // open the file...
  int recordCounter = 0; // this counter makes sure our offset doesnt change, perhaps a bit explicit but it is clear and gets the job done...

  if (!data.good()) // check and see if the data is good...
  {
    cout << "**Error: couldn't open data file '" << filename << "'." << endl;
    return newTree; // return empty tree...
  }

  //
  // Okay, read file record by record, and output each record of values:
  //
  data.seekg(0, data.end);  // move to the end to get length of file:
  streamoff length = data.tellg();

  streamoff pos = 0;  // first record at offset 0:
  string    value; // value that will hold each read in...


  while (pos < length)
  {
	values.clear(); // wipe the vector so it ready for use again....
    data.seekg(pos, data.beg);  // move to start of record:


    for (int i = 0; i < numColumn; ++i)  // read values, one per column:
    {
     data >> value; // read in...
     values.push_back(value); 	 // fill vector with the entire line
    }
	newTree.insert(values[colIndex],recordCounter); // insert with the relevant information...
	recordCounter = recordCounter + recordSize; // advance variable for another insert with doubled offset...
    pos += recordSize;  // move offset to start of next record:
  }
   return newTree; // return the fully fledged tree...
}
/* the purpose of this function is to accept a token and see if it s valid name int the meta data */
int nameSearch(vector<string> strings, string token)
{
  if(token == "*")
  {
	  return 2; // user inputted a star, which is still valid, so return a 2 for proper allocation...
  }
  for(int i = 0; i < strings.size(); i++)
  {
	  if(token == strings[i]) // string was found in the meta data list, return a 1...
	  {
		  return 1;
	  }
	
  }
	return 0; // string not found in the list, return a 0...
}
/* the purpose of this function is to accept a token that is in meta data and return the respective index where it is located*/
int getNameIndex(vector<string> strings, string token)
{
	for(int i = 0; i < strings.size(); ++i)
	{
		if(token == strings[i]) // name is found, this should always work, return index position...
		{
			return i;
		}
	}
	return -1; // for whatever reason the name that should be indexed is not found, so return -1...
}


int main()
{

  string tablename; // = "students";

  cout << "Welcome to myDB, please enter tablename> ";
  getline(cin, tablename);

  cout << "Reading meta-data..." << endl;
  //
  // TODO:
  //
  int recordSize =  0; // declare a offset...
  int numColumn = 0; // declare a numColumn per data line...
  vector<string> colNames; // vector that will hold all the strings from meta data...
  vector<int> colIndexes; // vector that will hold all the integers from meta data...
  inputMetaData(tablename,recordSize,numColumn,colNames,colIndexes);
  vector<avltree<string,streamoff>> myTrees; // vector of trees that will hold avl trees for indexed data columns...
	
  cout << "Building index tree(s)..." << endl;
  for(int colIndex = 0; colIndex < colNames.size(); ++colIndex)
  {
	  avltree<string,streamoff> tree; // declare a tree that will catch the copy from BuildIndexTree
	  
	  if(colIndexes[colIndex] == 1) // this means the column is indexed and needs an avl tree...
	  {
		  tree = BuildIndexTree(tablename,recordSize,numColumn,colIndex);
	  }
	  myTrees.push_back(tree); // add the tree, empty or not, into the tree vector...
  }


  for(int a = 0; a < numColumn; a++) // display the built trees and show heights and size...
  {

	  if(colIndexes[a] == 1)
	  {
		  cout << "Index column: " << colNames[a] << endl;
		  cout << " Tree size: " << myTrees[a].size() << endl;
		  cout << " Tree height: " << myTrees[a].height() << endl;
	  }
  }	
  //
  // Main loop to input and execute queries from the user:
  //
  string query;
  
  cout << endl;
  cout << "Enter query> ";
  getline(cin, query);

  while (query != "exit")
  {
	  int flagged = 0; // this flag will assure that only one error message occurs at once, it will also keep track of whether or not the input was valid

    vector<string> tokens = tokenize(query);

	if(tokens[0] != "select" && flagged == 0) // if the first line of the token isnt select, its bunk from the start...
	{
		cout << "Unknown query, ignored..." << endl;
		flagged = 1;

	}
	if(tokens[0] == "select" && flagged == 0) // query has not been sent correctly, but some structure of the query is there...
	{
		if(tokens[2] != "from")
		{
			cout << "Invalid select query, ignored..." << endl;
			flagged = 1;
		}
	}
	if(flagged == 0) // check the select column....
	{
	  int resultName = nameSearch(colNames,tokens[1]); // returns 1 if name is in vector, or 2 if its a *, else return zero...
	  if(resultName == 0)
	  {
		cout << "Invalid select column, ignored..." << endl;
		flagged++;
	
	  }
	}
	if(flagged == 0) // check the tablename....
	{
		if(tokens[3] != tablename)
		{
		  cout << "Invalid table name, ignored..." << endl;
		  flagged++;
		
		}
	}
	if(flagged == 0) // check the where column...
	{
	  int resultName2 = nameSearch(colNames,tokens[5]);// returns 1 if name is in vector, or 2 if its a *, else return zero...
	  if(resultName2 == 0 && flagged == 0)
	  {
		cout << "Invalid where column, ignored..." << endl;
		flagged++;
	  }
	}
	// Okay so now we know we have an acceptable query so now lets part it out....
	// ////////////////////////////////////////////////////////
	// ///////////////////////////////////////
	if(flagged != 1)
	{
		int resultName = nameSearch(colNames,tokens[1]);
		if(resultName == 1) // verify that we arent working with a star 
		{
			int indexOne = getNameIndex(colNames,tokens[1]);
			int indexTwo = getNameIndex(colNames,tokens[5]);
			if(colIndexes[indexOne] == 1) //select column is indexed...
			{
				
				if(colIndexes[indexTwo] == 1) // where column is indexed...
				{
				  vector<string> result = GetRecord(tablename,*myTrees[indexTwo].search(tokens[7]),numColumn);

				  cout << colNames[indexOne] << ": " <<  result[indexOne] << endl;
				}
				if(colIndexes[indexTwo] == 0) // where column is not indexed, so linear search...
				{
				  vector<streamoff> result = LinearSearch(tablename,recordSize,numColumn,tokens[7],indexTwo);
				  if(result.empty())
				  {
					 cout << "Not found..." << endl;
				  }
				  else
				  {
				    for(int i = 0; i < result.size(); i++)
				    { 
					 vector<string> result2 = GetRecord(tablename,result[i],numColumn);
					 cout << colNames[indexOne] << ": " << result2[indexOne] << endl;
				    }
				  }
				  
				}
			}
			if(colIndexes[indexOne] == 0) // select column isnt indexed...
			{
				if(colIndexes[indexTwo] == 1) // where column is indexed...
				{
					if(myTrees[indexTwo].search(tokens[7]) == nullptr)
					{
						cout <<"Not found..." << endl; // wasnt found in the tree...
					}
					else
					{
					vector<string> result = GetRecord(tablename,*myTrees[indexTwo].search(tokens[7]),numColumn);
					cout << colNames[indexOne] << ": " << result[indexOne] << endl;
					}
				}
				if(colIndexes[indexTwo] == 0) // where column is not indexed...
				{
					vector<streamoff> result = LinearSearch(tablename,recordSize,numColumn,tokens[7],indexTwo);
					if(result.empty())
					{
						cout <<"Not found..." << endl;
					}
					else
					{
						for(int i = 0; i < result.size(); i++)
						{
						   vector<string> result2 = GetRecord(tablename,result[i],numColumn);
					       cout << colNames[indexOne] << ": " << result2[indexOne] << endl;
						}
					}
				}
			}
		}
		else if(resultName == 2) // user entered a star
		{
			int indexTwo = getNameIndex(colNames,tokens[5]);
			
			if(colIndexes[indexTwo] == 1) // where column is indexed...
			{
				if(myTrees[indexTwo].search(tokens[7]) == nullptr)
				{
						cout <<"Not found..." << endl; // wasnt found in the tree...
				}
				else
				{
					
				
			   vector<string> result = GetRecord(tablename,*myTrees[indexTwo].search(tokens[7]),numColumn);
			   for(int i = 0; i < result.size(); i++)
			   {
				   cout << colNames[i] << ": " << result[i] << endl;
			   }
			   }
			}
			   if(colIndexes[indexTwo] == 0) // where column is not indexed...
			   {
					vector<streamoff> result = LinearSearch(tablename,recordSize,numColumn,tokens[7],indexTwo);
					if(result.empty())
					{
						cout <<"Not found..." << endl;
					}
					else
					{
						for(int i = 0; i < result.size(); i++)
						{
						   vector<string> result2 = GetRecord(tablename,result[i],numColumn);
					       for(int j = 0; j < result2.size(); j++)
						   {
							   cout << colNames[j] << ": " << result2[j] << endl;
						   }
						}
					}
			  }
		}
	}
			  	 	 	  	  	   	    	  
    cout << endl;
    cout << "Enter query> "; // get the next query...
    getline(cin, query);
  }

  //
  // done:
  //
  return 0;
}
