/*util.h*/

//
// Utility functions for myDB project
//
// joseph Lenaghan
// U. of Illinois, Chicago
// CS 251: Fall 2019
// Project #04
//

#pragma once

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>

using namespace std;

vector<string> EchoData(string tablename, int recordSize, int numColumns); // modified to return a vector of type string for each line of data..

vector<string> GetRecord(string tablename, streamoff pos, int numColumns); // gets  particular record line from a data set...

vector<streamoff> LinearSearch(string tablename, int recordSize, int numColumns, string matchValue, int matchColumn); // searches for non indexed data columns in a data set...
