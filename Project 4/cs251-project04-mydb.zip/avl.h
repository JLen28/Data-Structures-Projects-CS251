/*avl.h*/

//
// AVL tree: complete, balancing AVL tree class
//

#pragma once

#include <iostream>
#include <algorithm>  // std::max
#include <cstdlib>    // std::abs
#include <stack>
#include <vector>
#include <cassert>

using namespace std;

template<typename TKey, typename TValue>
class avltree
{
private: // tree node declaration..
  struct NODE
  {
    TKey   Key;
    TValue Value;
    int    Height;
    NODE*  Left;
    NODE*  Right;
  };

  NODE* Root;  // pointer to root node of tree (nullptr if empty)
  int   Size;  // # of nodes in the tree (0 if empty)
	
	void _inorder(NODE* cur);
	void _inorder_keys(NODE* cur, std::vector<TKey>& V);
	void _inorder_values(NODE* cur, std::vector<TValue>& V);
	void _inorder_heights(NODE* cur, std::vector<int>& V);
	void _copytree(NODE* cur);
	void _destructor(NODE* cur);
	void _RotateToFix(NODE* Parent, NODE* N); /// function that determines how to rotate...
	void _RightRotate(NODE* Parent, NODE* N);
	void _LeftRotate(NODE* Parent, NODE* N);

public:
  avltree();
  avltree(const avltree& other);
  ~avltree();
  
  avltree& operator=(const avltree& other);

  int size(); // return the size of the tree....
  int height(); // return the height of the tree...
  
  void clear(); // clear the tree for re-use...
  
  TValue* search(TKey key); // search for the value of a function and return a pointer to it
  void insert(TKey key, TValue value); // insert a value into the tree..
  
  int distance(TKey k1, TKey k2); // determine the distance between two nodes...

  void inorder(); // return the nodes in the tree in an inorder traversal...
  std::vector<TKey> inorder_keys();
  std::vector<TValue> inorder_values();
  std::vector<int> inorder_heights();

};
