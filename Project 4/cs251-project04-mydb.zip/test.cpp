/*test.cpp*/

//
// Lab week 09 / project #04
// 
// Testing for util.cpp?
//

#include <iostream>
#include <vector>

#include "avl.h"
#include "util.h"

#define CATCH_CONFIG_MAIN
#include "catch.hpp"

using namespace std;

TEST_CASE("(1) ???") 
{
	vector<string> result = GetRecord("students", 0 , 5);
	
	cout << result[0];
	cout << result[1];
	GetRecord("stations", 0 , 5);
	
	

}
