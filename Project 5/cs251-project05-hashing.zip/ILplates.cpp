/*ILplates.cpp*/

//
// Hashing functions to store (license plate, amount) pairs
// using linear probing.
//
// Joe Lenaghan
// U. of Illinois, Chicago
// CS 251: Fall 2019
// Project 05
//

#include <iostream>
#include <string>
#include <math.h>
#include <cmath>

#include "ILplates.h"

using namespace std;


//
// Hash:
//
// Given a specialized Illinois license plate, returns an index into
// the underyling hash table.  If the given plate does not follow the
// formatting rules given below, -1 is returned.
//
// Personalized:
//   letters and numbers, with a space between the letters 
//   and numbers.  Format: 1-5 letters plus 1..99 *OR* 
//   6 letters plus 1..9
//
//   Examples: A 1, B 99, ZZZZZ 1, ABCDEF 3
//
// Vanity:
//   Format: 1-3 numbers *OR* 1-7 letters
// 
//   Examples: 007, 1, 42, X, AAA, ZZZEFGH
//
int ILplates::Hash(string plate)
{
  long long index = -1;
  int pltLen = plate.length(); // get the length of the string...
	  for(int i = 0; i < pltLen; i++)
	  {
		  if(pltLen > 3) // this means we know its not an all numbers vanity plate...
		  {
			  if(isdigit(plate[i]))
			  {
				  return -1; //error...
			  }
		  }
		  if(plate[i] == '@' || plate[i] == '*') // check for special characters that cannot be on a license plate...
		  {
			  return -1; //error...
		  }
		  if(islower(plate[i])) // check for lowercase inputs...
		  {
			 return -1; //error...
		  }
		  if(plate[i] == ' ') // check for personalized plate...
		  {
			 if(( pltLen < 3) || ( pltLen > 8)) // minimum input is something like "A 1" and max output is "ABCDEF 3"
			 {
				  return -1; //error...
			 }
			 int j = 0; // counter
			 int bin = 0; // holds the ascii values of each 
			 while(plate[j] != ' ') // while we havent hit the space in the plate
			 {
				 if(j < 2)
				 {
					 bin += ('A' - plate[j]); // add up all the chars before the case and convert them to ints, then add to the bin...

				 }
				 j++; // advance traversal counter...
			 }
			 int numChars = j; // number of characters for said input, useful later...
			 int notPast2 = 0; // this counter keeps track of whether or not we have exceeded the format of one or two digits after the space...
			 string numbers; // string to hold the digits we push after the space ' '
			 int flag =0; // flag is default set to zero or false, I prefer to work in the world of ints instead of bools...
			  j++; // advance off the spacc (' ') onto the first digit of the personalized plate...
			  notPast2++; // to account for us pushing the first digit into the string...
			 while(j<pltLen) // j should now be 2 or 1 space away from the end 
			 {
				 flag = 1; // the flag has been tripped, this means we have digits and a valid stoi can occur...
				 if(notPast2 > 2) // if this exceeds two, we have two many digits in the plate after the space, therefore it is invalid
				 {
					return -1; //error...
				 }
				 numbers.push_back(plate[j]); // add the digits to the string...
				 j++; //advance traversal counter...
				 notPast2++; // advance error check counter...

			 }// error checking personalized plates completed, time to hash...
			 for(size_t x = 0; x < numbers.length(); x++)
			 {
				 if(!isdigit(numbers[x]))
				 {
					 return -1; // error...
				 }
			 }
			 if(flag == 1) // this means that after the space, only numbers where pushed in, otherwise this flag is not tripped...
			 {
			   int nums = stoi(numbers); // convert string to int...
			 


				index = abs((bin * pow(26,numChars)) / 2 + nums);
				return index % HT.Size(); // return the hashed index modded by the hashtable size...
			 }
			 else
			 {
				 index = abs(bin * pow(26,numChars) / 2); // Hash...
				 return index % HT.Size(); // return the hashed index modded by the hashtable size...
			 }

		  } // OKAY so if we got here then we know the string is a vanity plate and need to check accordingly..
	  }
	  if((plate[0] == '0')
		||(plate[0] == '1')
		||(plate[0] == '2')
		||(plate[0] == '3')
		||(plate[0] == '4')
		||(plate[0] == '5')
		||(plate[0] == '6')
		||(plate[0] == '7')
		||(plate[0] == '8')
		||(plate[0] == '9')) // block checks if plate is of vanity type Format numbers 1-3...
	  {
		  if(pltLen > 3)
		  {
			  return -1; //error...
		  }
		  for(int x = 0; x < pltLen; x++)
		  {
			  if(!isdigit(plate[x]))
			  {
				  return -1; //error...
			  }
		  }
		  int nums = stoi(plate);
		  index = abs(nums * pow(10,3));
		  return index % HT.Size(); // return the hashed index modded by the hashtable size...
	  }
	else // vanity plate of type 1 -7 letters...
	{
		if(pltLen > 7) // plate exceeds the vanity limit for format...
		{
			return -1; //error...
		}
		int bin = 0; // declare the bin
		for(int i = 0; i < pltLen; i++)
		{
			bin += ('A' - plate[i]); // update bin for length
		}
		index = abs(bin * pow(26,7)); // hash the index...
		return index % HT.Size(); // return the hashed index modded by the hashtable size...
		
	}
	
			
  return index % HT.Size(); // return the hashed index modded by the hashtable size...
}


//
// Search
// 
// Hashes and searches for the given license plate; returns the 
// associated value for this plate if found, or -1 if not found.
//
int ILplates::Search(string plate)
{
	long index = Hash(plate);
	int counter = 0;
	bool empty = false;
	string name;
	int fine = 0;
	while(counter < HT.Size())
	{
		HT.Get(index,empty,name,fine);
		if(empty == true)
		{
			return -1;
		}
		if(name == plate)
		{
			return fine;
		}
		index = (index +1) % HT.Size();
		++counter;	
	}


  return -1;
}


//
// Insert
//
// Inserts the given (plate, newValue) into the hash table,
// overwriting an existing value if there.
//
void ILplates::Insert(string plate, int newValue)
{
	long index = Hash(plate);
	int counter = 0;
	bool empty = false;
	string holder;
	int pholder = 0;
	//cout << " get here before the while for" << plate << endl;
	while(counter < HT.Size())
	{
		HT.Get(index,empty,holder,pholder);
		if(empty == true)
		{
			HT.Set(index,plate,newValue);
			return;
		}
		if(holder == plate)
		{
			HT.Set(index,plate,newValue);
			return;
		}
		else
		{
			index = (index + 1) % HT.Size();
			++counter;
		}
	}

}
