/*main.cpp*/

//
// Hashing program for specialized Illinois license plates,
// which processes an input file of license plates and fines.
// The output is the total fines per license plate, in 
// sorted order.
//
// Original author: Prof. Joe Hummel
// Modified by: Joe Lenaghan
//
// U. of Illinois, Chicago
// CS 251: Fall 2019
// Project 05
//

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <random>
#include <cassert>

#include "ILplates.h"

using namespace std;

/*LL is necessary for us to properly sort the characters of the hash table and organize their fines*/
struct Node {
	string Plate = "";
	int Fine = 0;
	Node* Next;
	
}; // end struct definition...
//
// hashInput:
//
void hashInput(string basename, ILplates& hashplates)
{
  string infilename = basename + ".txt";
  ifstream infile(infilename);

  if (!infile.good())
  {
    cout << endl;
    cout << "**Error: unable to open input file '" << infilename << "', exiting." << endl;
    cout << endl;
    exit(-1);
  }

  //
  // input the plates and fines:
  //
  cout << "Reading '" << infilename << "'..." << endl;
  cout << "Sorting..." << endl;
  cout << "Writing 'tickets1-output.txt" << endl;

  string fine;
  string plate;

  getline(infile, fine);

  //
  // for each pair (fine, license plate), hash and store/update fine:
  //
  while (!infile.eof())
  {
    getline(infile, plate);

    //cout << fine << endl;
    //cout << plate << endl;

    // 
    // is plate valid?  Only process valid plates:
    //
    if (hashplates.Hash(plate) >= 0)  // yes:
    {
		
      int amount = hashplates.Search(plate);

      if (amount < 0)  // not found:
      {
        hashplates.Insert(plate, stoi(fine));
      }
      else  // we found it, so update total in hash table:
      {
        amount += stoi(fine);
        hashplates.Insert(plate, amount);
      }

    }//valid

    getline(infile, fine);
  }
}

/*algorithm makes use of the string function compare to check for alphabetization, utilizes a LL to store each plate and fine into a node*/
void insertInOrder(Node*& hd, string plate, int fine)
{
	Node* curr = hd; // curr will traverse the list..
	Node* prev = nullptr; // prev is responsible for following cur when we encounter a position for insert...
	Node* tmp = new Node(); // declaring a node to hold new info that will be added to the LL
	tmp->Plate = plate; // give tmp the plate to be inserted/updated...
	tmp->Fine = fine; // give tmp the fine to be inserted/updated....
  if(hd == nullptr) // initial check to see if hd is a nullptr...
  {
    hd = tmp;
    return;
  }
  int flag = 0; // flag is off by default, will trigger if its time to insert...
	while((curr != nullptr) && flag != 1) 
	{
    int i = curr->Plate.compare(plate);
    if(curr->Plate.compare(plate) == 0) // equal strings...
    {
      curr->Fine = fine; // update the fine with an updated total...
      return;
    }
    if(i > 0) // if the flag is tripped, that means we've hit our place to insert and time to exit the while loop...
    {
      flag = 1;
    }
    else
    {
      prev = curr; // adance pointer following head pointer...
      curr = curr->Next; // advance head pointer...
    }
	}
  tmp->Next = curr; // linking the new Node to the LL...
  if(prev == nullptr)
  {
    hd = tmp; // an additional check for an empty head... perhaps unnecessary?
  }
  else
  {

    prev->Next = tmp; // connect prev to the newly inserted node, this should alphabetically come before tmp...
  }
}// end sort alg....

/* debugging function more or less, shows the LL at any given point it is called...*/
void show(Node* hd)
{
  while(hd != NULL)
  {
    cout << "PLATE: " << hd->Plate << " " << "FINE AMNT: " << hd->Fine << endl;
    hd = hd->Next;
  }
}// end show...

/*function accepts the name of the file and the LL and uses it to produce an outfile*/
void hashOutput(string basename, Node* hd)
{
	string outfilename = basename + "-output.txt"; // create the name of the outfile...
	
	ofstream outfile(outfilename); // initialize our outfile...
	
	while(hd != nullptr)
	{
		outfile << "\"" << hd->Plate << "\"" << " $" << hd->Fine << endl; // write the outfile using the plate and total fine...
		hd = hd->Next; // advance another node in the LL...
	}
	
}// end output function...




int main()
{
  int    N;        // = 10000;
  string basename; // = "tickets1";
  Node* Hd = nullptr; // declare the LL...

  cout << "Enter hashtable size> ";
  cin >> N;

  hashtable<string, int>  ht(N);
  ILplates                hashplates(ht);

  cout << "Enter base filename> ";
  cin >> basename;
  cout << endl;

  //
  // process input file of fines and license plates:
  //
  hashInput(basename, hashplates);

  vector<string> plates = ht.Keys(); // vector of characters in hashtable...
  vector<int> amounts = ht.Values(); // vector of ints in hashtable...
  for(size_t i = 0; i < plates.size(); i++)
  {
	 insertInOrder(Hd,plates[i],amounts[i]); // sort the vectors into a linked list...
  }
	
	
  hashOutput(basename,Hd); // function call to write the output for the text file...




  //
  // done:
  //
  return 0;
}