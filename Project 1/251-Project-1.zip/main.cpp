//
// Project #01: input movie review data from a file, and output moviename, # of 
// reviews, average review, and # of reviews per star.
//
// File example "movie1.txt":
//   Finding Nemo
//   5
//   4
//   5
//   4
//   5
//   -1
//
// Output:
//  Movie: Finding Nemo
//  Num reviews: 5
//  Avg review:  4.6
//  5 stars: 3
//  4 stars: 2
//  3 stars: 0
//  2 stars: 0
//  1 star:  0
//

#include <iostream>
#include <fstream>
#include <string>

#include "myvector.h"
#pragma once
using namespace std;

// functions from student.cpp:
myvector<int> InputData(string filename, string& moviename);
double   GetAverage(myvector<int> reviews);
myvector<int> GetNumStars(myvector<int> reviews);
int main()
{
  cout << endl;
  cout << "PROGRAM INFO: CS 251 PROJECT ONE ";
  cout << "SKELETON PROVIDED BY PROFFESOR JOE HUMMEL" << endl;
  cout << "PROGRAM MODIFIED BY MYSELF, JOSEPH LENAGHAN" << endl;
  cout << "Program is designed to taken in a data set of a movie" << endl;
  cout << "and using a self made vector class, store the information" << endl;
  cout << "regarding a particular movie entered by the user" << endl;
  cout << "start by entering a movie data set in the format of" << endl;;
  cout << "'datasetname.txt,|| ex. 'movie1.txt' ||" << endl;
  cout << "-------------------------------------------" << endl << endl;
  myvector<int>  reviews;
  myvector<int>  numstars;
  double    avg;
  string    filename, moviename;

  //
  // 1. input filename and then the review data:
  //
  cin >> filename;

  reviews = InputData(filename, moviename);
  cout << endl;
  cout << "Movie: " << moviename << endl;
  cout << "Num reviews: " << reviews.size() << endl;

  //
  // 2. average review
  //
  avg = GetAverage(reviews);
  cout << "Avg review:  " << avg << endl;

  //
  // 3. # of 5 stars, 4 stars, etc
  //
  numstars = GetNumStars(reviews);

  myvector<int> w;
  for(int i = 0; i < 20; i++){
    w.push_back(i);
  }
  cout << w.rangeof(0,10);



  for (int i = numstars.size(); i > 0; --i)  
  {
    //
    // i is 5, 4, 3, 2, 1:
    //
    if (i == 1)
      cout << i << " star:  " << numstars.at(i - 1) << endl;
    else
      cout << i << " stars: " << numstars.at(i - 1) << endl;
  }

  cout << "-----------------------------------------------" << endl;


  return 0;
}
