/*myvector.h*/

// 
// Joseph Lenaghan 
// U. of Illinois, Chicago
// CS 251: Fall 2019
// 
// Project #01: myvector class that mimics std::vector, but with my own
// implemenation outlined as follows:
//
//  a vector that stores the number of moon cycles per month(and potentially per year), //  it will function very similarily to the movie reviews.
//

#pragma once

#include <iostream>  // print debugging
#include <cstdlib>   // malloc, free

using namespace std;

template<typename T>
class myvector
{
private:
struct NODE{          // STRUCT DEFINED HERE:
  T  Data;            // POINTER TO NEXT NODE AND A TEMPLATED DATA VALUE...
  NODE* Next;
}; // end struct definition

 NODE* Head; // Head defined...
 NODE* Tail; // Tail defined...
 int   Size; // Size defined...
 NODE* lastNode; // lastNode defined...
 int   lastIndex; // lastIndex defined...

public:
  // default constructor:
  myvector()
  {
    Head = nullptr; // Head initialized...
    Tail = nullptr; // Tail initialized..
    Size = 0; // Size initialized...

    lastNode = nullptr; // lastNode initialized...
    lastIndex = -1; // lastIndex initialized...
  }
 // constructor with initial size:
  myvector(int initial_size)
  {
   Head = nullptr; // Head initialized...
   lastNode = nullptr; // lastNode initialized...
   Tail = nullptr; // Tail initialized..
   Size = 0; // Size initialized...

   for(int i = 0; i < initial_size; i++){
     push_back(0);
   }
   
  }

  // copy constructor for parameter passing:
  myvector(const myvector& other)
  {
    NODE* tmp = new NODE(); // tmp pointer created to walk down Other's LL and add values to our copy...
    tmp = other.Head;
    this->Head = nullptr; // this used to distinguish Heads...
    this->Tail = nullptr; // this used to distinguish Tails...

    while(tmp!=nullptr){
      push_back(tmp->Data);
      tmp=tmp->Next;
    }
    
   this->Size = other.Size; // this used to distinguish Sizes
  }
  
  // simple Size function returns an integer corresponding to the elements in the linked list, important that it is not templated...

  int size()
  {
    return Size;
  }
  
  // at function creates a temporary pointer upon calling, pointer utilizes the last index to find position and their neighbor->
  // (else if ( i == lastIndex+1)
  // if all else fails, temp is still set to head and can walk down the entirety of the linked list to find i...

 T& at(int i)
 {
   NODE* temp = Head; 
    
   if (i == 0){ // this is triggered only if the at function call is made at position zero AKA the list's Head...
   
      lastNode  = Head;
      lastIndex = 0;
      return Head -> Data;
   }
   else if (i == lastIndex + 1) // this is triggered if the i value in question is precisely 1 position after the last index,
   {                            // greatly reducing the amount of time needed to find the return...
     lastIndex = lastIndex + 1;
      for (int j = 0; j < lastIndex; ++j){
         temp = temp -> Next;
      }
      lastNode = temp;
      return lastNode->Data;
   }
   else // else addresses an i value that is not readily accesible, so temp will start all the way from head and work down the LL,
   {    // a foolproof way of guranteeing a return.
     lastIndex = 0;
      while (lastIndex != i)
      {
         temp = temp->Next;
         lastIndex++;
      }
      return temp -> Data;
   }
 } // end at function...

 T erase(int i){
   NODE* q = Head; 
   NODE* p = Head->Next;
   T value;
   if(i == 0){
     value = Head->Data;  
     Head = Head->Next;
     lastIndex = 0;
     Size--;
     return value;
   }
   lastIndex = 0;
   while(lastIndex != i - 1){
     q = q->Next;
     p = p->Next;
     lastIndex++;
   
     if(p->Next == nullptr){ // tail hit
       value = Tail->Data;
       Tail = p;
       Size--;
       return value;
      }
     } // else, it is a node in the middle of the list,
      value = p->Data; // so data value stored in value variable
      q->Next = p->Next; // and the link in the list is re-established
      p->Next = nullptr; // with the deleted nodes next...
      p->Data = 0; // Size is downsized...
      Size--;
      return value; // return value from deleted node..
 } // end of erase...

 T& operator[] (int i){
   return this->at(i);
 } // end operator...


 T* rangeof(int i, int j){
   int range = j - i + 1; // range found...
   T* arr = new T[range]; // array and pointer for array initialized...
   int lastIndex = 0; // lastIndex serves as a counter...

   for(int q = i; q <= j; q++){ // from the start of range to the end
     arr[lastIndex] = this->at(q); // add corresponding elements to the 
     lastIndex++; // array and increment index...
   }
    return arr; // lastly return the array...
   }// end rangeof...

 


  void push_back(T value)
  {
    NODE* newNode = new NODE(); // new node that will hold data value defined...
    newNode->Data = value; // newNode's data value is set, stays templated...
    newNode->Next = nullptr; // since it is pushed to the back, we want to make suret the next pointer is not point of into space...

   if(Head == nullptr){
     Head = newNode; // empty list...
   }
   else{
     Tail->Next = newNode; // this links our newNode to the LL...
   }
   Tail = newNode; // Tail is set to equal the newly pushed in node...

   Size++; // Size incremented to account for growing list...
  } // end push_back...
   

}; // end class definition...

